local QUEST = {};

QUEST.ID = 204
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Anitlion Quest (4/10)";
QUEST.Description = "This bug like creature is easy to kill but don't underestimate their speed and numbers. If too many of them attack you at once you will die. They are extremely fast so make sure your ready to run. They hid all around Tatooine so don't be caught slacking or you will be its next meal.";
QUEST.Objective = "Find and kill 40 antilion then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 203;
QUEST.ObjectiveRequirement = 40;
QUEST.ObjectiveClass = "npc_antlion";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 4000 )
	ply:addMoney(7500)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Antilion_4", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);