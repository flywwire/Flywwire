local QUEST = {};

QUEST.ID = 104
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Anitlion Guard Quest (4/10)";
QUEST.Description = "This bug is much bigger than the others. They are fast and can over whelm you within seconds. They are also stronger than the other ones. Go to Tatooine and be ready for a fight or you will be dinner.";
QUEST.Objective = "Find and kill 40 antilion guards then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 103;
QUEST.ObjectiveRequirement = 40;
QUEST.ObjectiveClass = "npc_antlionguard";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 4000 )
	ply:addMoney(7500)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Antilionguard_4", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);