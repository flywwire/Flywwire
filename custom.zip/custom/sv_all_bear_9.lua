local QUEST = {};

QUEST.ID = 2009
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Snow Bear Quest (9/10)";
QUEST.Description = "Do not be fooled by this creature, it may be easy to kill one on one, but these snow bears run in packs and can overwhelm you. Make sure you are prepared when hunting these creatures down.";
QUEST.Objective = "Find and kill 90 snow bear then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 2008;
QUEST.ObjectiveRequirement = 90;
QUEST.ObjectiveClass = "npc_vj_vi_bear";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 6500 )
	ply:addMoney(20000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Bear_9", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);