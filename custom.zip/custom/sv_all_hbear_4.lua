local QUEST = {};

QUEST.ID = 2104
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Horned Bear Quest (4/5)";
QUEST.Description = "Stronger than a normal snow bear and quicker too. These guys with their long tusks will hit ya but if you can avoid it you better hope they don’t get a hold of you with their massive bear hands.";
QUEST.Objective = "Find and kill 15 horned bear then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 2103;
QUEST.ObjectiveRequirement = 15;
QUEST.ObjectiveClass = "npc_vj_vi_bear2";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 6000 )
	ply:addMoney(7500)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Hbear_4", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);