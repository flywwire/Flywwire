local QUEST = {};

QUEST.ID = 806
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Hydralisk Quest (5/5)";
QUEST.Description = "This slimy beast has long armes and pinchers at the ends of these arms. Be careful, they have a long reach and if your not looking they will pop your head off your body. Be ready to fight as they are scattered all around the plains of Tatooine, ready to hunt.";
QUEST.Objective = "Find and kill 20 hydralisk then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Legndary Crystal, Credits, and XP";
QUEST.NeedsToHaveCompleted = 804;
QUEST.ObjectiveRequirement = 20;
QUEST.ObjectiveClass = "npc_vj_st_hydralisk";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 1;
QUEST.Enabled = true;

local LegndaryCrystal = {
	"[Legendary] Blue Crystal (Saw Tooth)",
	"[Legendary] Light Blue Crystal (Saw Tooth)",
	"[Legendary] Green Crystal (Saw Tooth)",
	"[Legendary] Lime Green Crystal (Saw Tooth)",
	"[Legendary] Orange Crystal (Saw Tooth)",
	"[Legendary] Blood Orange Crystal (Saw Tooth)",
	"[Legendary] Pink Crystal (Saw Tooth)",
	"[Legendary] Purple Crystal (Saw Tooth)",
	"[Legendary] Red Crystal (Saw Tooth)",
	"[Legendary] Yellow Crystal (Saw Tooth)",
	"[Legendary] Blue Crystal (Cyan Core)",
	"[Legendary] Green Crystal (Green Core)",
	"[Legendary] Red Crystal (Orange Core)",
	"[Legendary] Magenta Crystal (Pink Core)",
	"[Legendary] Red Crystal (Yellow Core)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
	local getitem = table.Random( LegndaryCrystal )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 7500 )
	ply:addMoney(50000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Hydralisk_5", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);