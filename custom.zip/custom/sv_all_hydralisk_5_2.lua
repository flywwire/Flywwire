local QUEST = {};

QUEST.ID = 807
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Hydralisk Quest (5/5)";
QUEST.Description = "This slimy beast has long armes and pinchers at the ends of these arms. Be careful, they have a long reach and if your not looking they will pop your head off your body. Be ready to fight as they are scattered all around the plains of Tatooine, ready to hunt.";
QUEST.Objective = "Find and kill 20 hydralisk then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 806;
QUEST.ObjectiveRequirement = 20;
QUEST.ObjectiveClass = "npc_vj_st_hydralisk";
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 3600;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
	ply:AddSkillXP( 7500 )
	ply:addMoney(50000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Hydralisk_5_2", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);