local QUEST = {};

QUEST.ID = 2202
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Ice Dragon Quest (2/5)";
QUEST.Description = "With the ice it shoots, there is no way of protecting yourself. Best you can do is avoid the freezing cold. Better cut its head off before it blows and the land of ilum.";
QUEST.Objective = "Find and kill 3 ice dragon then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 2201;
QUEST.ObjectiveRequirement = 3;
QUEST.ObjectiveClass = "npc_vj_vi_ancient_beokros";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 4000 )
	ply:addMoney(2500)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Idragon_2", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);