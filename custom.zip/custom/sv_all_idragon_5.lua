local QUEST = {};

QUEST.ID = 2206
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Ice Dragon Quest (5/5)";
QUEST.Description = "With the ice it shoots, there is no way of protecting yourself. Best you can do is avoid the freezing cold. Better cut its head off before it blows and the land of ilum.";
QUEST.Objective = "Find and kill 10 ice dragon then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Legndary Crystal, Credits, and XP";
QUEST.NeedsToHaveCompleted = 2204;
QUEST.ObjectiveRequirement = 10;
QUEST.ObjectiveClass = "npc_vj_vi_ancient_beokros";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 1;
QUEST.Enabled = true;

local LegndaryCrystal = {
	"[Legendary] Blue Crystal (Saw Tooth)",
	"[Legendary] Light Blue Crystal (Saw Tooth)",
	"[Legendary] Green Crystal (Saw Tooth)",
	"[Legendary] Lime Green Crystal (Saw Tooth)",
	"[Legendary] Orange Crystal (Saw Tooth)",
	"[Legendary] Blood Orange Crystal (Saw Tooth)",
	"[Legendary] Pink Crystal (Saw Tooth)",
	"[Legendary] Purple Crystal (Saw Tooth)",
	"[Legendary] Red Crystal (Saw Tooth)",
	"[Legendary] Yellow Crystal (Saw Tooth)",
	"[Legendary] Blue Crystal (Cyan Core)",
	"[Legendary] Green Crystal (Green Core)",
	"[Legendary] Red Crystal (Orange Core)",
	"[Legendary] Magenta Crystal (Pink Core)",
	"[Legendary] Red Crystal (Yellow Core)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
	local getitem = table.Random( LegndaryCrystal )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 7500 )
	ply:addMoney(50000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Idragon_5", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);