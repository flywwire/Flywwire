local QUEST = {};

QUEST.ID = 903
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Impaler Quest (3/5)";
QUEST.Description = "These things blend in with the land of Endor. They sneak and hunt and when your not ready is when they attack. These green slimy things enjoy to kill with their long arms and pinchers just ready to take your head from your spine. Beware as they can finish you with one pinch. Go to Endor and destroy them.";
QUEST.Objective = "Find and kill 10 impaler then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Epic Crystal, Credits, and XP";
QUEST.NeedsToHaveCompleted = 902;
QUEST.ObjectiveRequirement = 10;
QUEST.ObjectiveClass = "npc_vj_st_impaler";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

EpicCrystals = {
    "[Epic] Blue Crystal (Corrupted)",
	"[Epic] Light Blue Crystal (Corrupted)",
	"[Epic] Green Crystal (Corrupted)",
	"[Epic] Lime Green Crystal (Corrupted)",
	"[Epic] Orange Crystal (Corrupted)",
	"[Epic] Blood Orange Crystal (Corrupted)",
	"[Epic] Pink Crystal (Corrupted)",
	"[Epic] Purple Crystal (Corrupted)",
	"[Epic] Red Crystal (Corrupted)",
	"[Epic] Yellow Crystal (Corrupted)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
	local getitem = table.Random( EpicCrystals )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 4500 )
	ply:addMoney(10000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Impaler_3", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);