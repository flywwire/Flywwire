local QUEST = {};

QUEST.ID = 904
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Impaler Quest (4/5)";
QUEST.Description = "These things blend in with the land of Endor. They sneak and hunt and when your not ready is when they attack. These green slimy things enjoy to kill with their long arms and pinchers just ready to take your head from your spine. Beware as they can finish you with one pinch. Go to Endor and destroy them.";
QUEST.Objective = "Find and kill 15 impaler then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 903;
QUEST.ObjectiveRequirement = 15;
QUEST.ObjectiveClass = "npc_vj_st_impaler";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 6000 )
	ply:addMoney(7500)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Impaler_4", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);