local QUEST = {};

QUEST.ID = 605
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Raptor Quest (5/10)";
QUEST.Description = "These Raptors are violent. It is recommended to not mess with them unless you have a crew with you. These green things look alot like Zerglings but now they have wings. Try to run but you will fail. Go and try to kill them if you can.";
QUEST.Objective = "Find and kill 50 raptors then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Epic Crystal, Credits, and XP";
QUEST.NeedsToHaveCompleted = 404;
QUEST.ObjectiveRequirement = 50;
QUEST.ObjectiveClass = "npc_vj_st_raptor";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

EpicCrystals = {
    "[Epic] Blue Crystal (Corrupted)",
	"[Epic] Light Blue Crystal (Corrupted)",
	"[Epic] Green Crystal (Corrupted)",
	"[Epic] Lime Green Crystal (Corrupted)",
	"[Epic] Orange Crystal (Corrupted)",
	"[Epic] Blood Orange Crystal (Corrupted)",
	"[Epic] Pink Crystal (Corrupted)",
	"[Epic] Purple Crystal (Corrupted)",
	"[Epic] Red Crystal (Corrupted)",
	"[Epic] Yellow Crystal (Corrupted)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
	local getitem = table.Random( EpicCrystals )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 4500 )
	ply:addMoney(10000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Raptor_5", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);