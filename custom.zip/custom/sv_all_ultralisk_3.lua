local QUEST = {};

QUEST.ID = 703
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] Ultralisk Quest (3/5)";
QUEST.Description = "This creature is quite terrifying. Its hits can knock you down hard and kill you fast. It's best to fight him in groups. He is fast and has sharp horns that can pierce you very easily.";
QUEST.Objective = "Find and kill 6 ultralisk then return to me for your reward.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Epic Crystal, Credits, and XP";
QUEST.NeedsToHaveCompleted = 702;
QUEST.ObjectiveRequirement = 6;
QUEST.ObjectiveClass = "npc_vj_st_ultralisk";
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 0;
QUEST.Enabled = true;

EpicCrystals = {
    "[Epic] Blue Crystal (Corrupted)",
	"[Epic] Light Blue Crystal (Corrupted)",
	"[Epic] Green Crystal (Corrupted)",
	"[Epic] Lime Green Crystal (Corrupted)",
	"[Epic] Orange Crystal (Corrupted)",
	"[Epic] Blood Orange Crystal (Corrupted)",
	"[Epic] Pink Crystal (Corrupted)",
	"[Epic] Purple Crystal (Corrupted)",
	"[Epic] Red Crystal (Corrupted)",
	"[Epic] Yellow Crystal (Corrupted)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
	local getitem = table.Random( EpicCrystals )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 4500 )
	ply:addMoney(10000)
end

function QUEST:OnQuestInitialized()
    hook.Add("OnNPCKilled", "gQuest.All_Ultralisk_3", function(npc, ent)
        if (IsValid(npc) and IsValid(ent) and ent:IsPlayer()) then
            if (type(self.ObjectiveClass) == "table" and table.HasValue(self.ObjectiveClass, npc:GetClass()) or type(self.ObjectiveClass) == "string" and self.ObjectiveClass == npc:GetClass()) then
                if (ent:GQ_HasAcceptedQuest(self.ID)) then
                    ent:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);