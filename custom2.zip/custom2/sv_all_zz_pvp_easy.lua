local QUEST = {};

QUEST.ID = 501
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] PVP Quest (Easy)";
QUEST.Description = "Find and kill 10 people of the opposing faction without dying and receive a special crystal.";
QUEST.Objective = "Kill 10 people without dying.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Random Legendary Crystal";
QUEST.ObjectiveRequirement = 10;
QUEST.ObjectiveClass = "player";
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 1800;
QUEST.Enabled = false;

local LegndaryCrystal = {
	"[Legendary] Blue Crystal (Saw Tooth)",
	"[Legendary] Light Blue Crystal (Saw Tooth)",
	"[Legendary] Green Crystal (Saw Tooth)",
	"[Legendary] Lime Green Crystal (Saw Tooth)",
	"[Legendary] Orange Crystal (Saw Tooth)",
	"[Legendary] Blood Orange Crystal (Saw Tooth)",
	"[Legendary] Pink Crystal (Saw Tooth)",
	"[Legendary] Purple Crystal (Saw Tooth)",
	"[Legendary] Red Crystal (Saw Tooth)",
	"[Legendary] Yellow Crystal (Saw Tooth)",
	"[Legendary] Blue Crystal (Cyan Core)",
	"[Legendary] Green Crystal (Green Core)",
	"[Legendary] Red Crystal (Orange Core)",
	"[Legendary] Magenta Crystal (Pink Core)",
	"[Legendary] Red Crystal (Yellow Core)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    local howrare = math.random( 1, 1000 )
	local getitem = table.Random( LegndaryCrystal )
		if howrare >= 1 && howrare <= 750 then
			wOS:HandleItemPickup( ply, getitem )
			ply:AddSkillXP( 2500 )
		end
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "gQuest.All_Zz_Pvp_Easy", function(victim, inflictor, attacker)
        if (IsValid(victim)) then
            if (victim:GQ_HasAcceptedQuest(self.ID)) then
                victim:GQ_AbandonQuest(self.ID, false);
                victim:GQ_PutQuestOnCooldown(self.ID, true);
                victim:SendGQTextNotification(true, "uiNotificationQuestFailed", self.Name, gQuest.Red, 10);
                victim:GQ_TrackQuest(self.ID, true);
            end

            if (IsValid(attacker) and attacker:IsPlayer()) then
                if (attacker:GQ_HasAcceptedQuest(self.ID)) then
                    attacker:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);