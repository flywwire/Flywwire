local QUEST = {};

QUEST.ID = 502
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] PVP Quest (Master)";
QUEST.Description = "Find and kill 25 people of the opposing faction without dying and receive a special crystal.";
QUEST.Objective = "Kill 25 people without dying.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Random Mythic Crystal";
QUEST.ObjectiveRequirement = 25;
QUEST.ObjectiveClass = "player";
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 900;
QUEST.Enabled = false;

local MythicCrystal1 = {
	"[Mythic] Dark Green Crystal (Corrupted) (DI)",
	"[Mythic] Dark Blue Crystal (Corrupted) (DI)",
	"[Mythic] Dark Purple Crystal (Corrupted) (DI)",
	"[Mythic] Dark Red Crystal (Corrupted) (DI)",
	"[Mythic] Dark Blue Crystal (Saw Tooth) (DI)",
	"[Mythic] Dark Green Crystal (Saw Tooth) (DI)",
	"[Mythic] Dark Purple Crystal (Saw Tooth) (DI)",
	"[Mythic] Dark Red Crystal (Saw Tooth) (DI)",
	"[Mythic] Azure Crystal (Corrupted)",
	"[Mythic] Amber Crystal (Corrupted)",
	"[Mythic] Emerald Crystal (Corrupted)",
	"[Mythic] Fire Orange Crystal (Corrupted)",
	"[Mythic] Magenata Crystal (Corrupted)",
	"[Mythic] Violet Crystal (Corrupted)",
	"[Mythic] Amber Crystal (Saw Tooth) (DI)",
	"[Mythic] Azure Crystal (Saw Tooth) (DI)",
	"[Mythic] Emerald Crystal (Saw Tooth) (DI)",
	"[Mythic] Fire Orange Crystal (Saw Tooth) (DI)",
	"[Mythic] Magenata Crystal (Saw Tooth) (DI)",
	"[Mythic] Violet Crystal (Saw Tooth) (DI)",
}

local MythicCrystal2 = {
	"[Mythic] Purple Crystal (Blue Core)",
	"[Mythic] Silver Crystal (Blue Core)",
	"[Mythic] Purple Crystal (Pink Core)",
	"[Mythic] Yellow Crystal (Pink Core)",
	"[Mythic] Blue Crystal (Yellow Core)",
	"[Mythic] Dark Blue Crystal (Blue Core)",
	"[Mythic] Dark Red Crystal (Red Core)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    local howrare = math.random( 1, 1000 )
		local getitem = table.Random( MythicCrystal1 )
			if howrare >= 1 && howrare <= 750 then
				wOS:HandleItemPickup( ply, getitem )
				ply:AddSkillXP( 5000 )
			end
		local getitem2 = table.Random( MythicCrystal2 )
			if howrare >= 751 && howrare <= 1000 then
				wOS:HandleItemPickup( ply, getitem2 )
				ply:AddSkillXP( 5000 )
			end
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "gQuest.All_Zz_Pvp_Master", function(victim, inflictor, attacker)
        if (IsValid(victim)) then
            if (victim:GQ_HasAcceptedQuest(self.ID)) then
                victim:GQ_AbandonQuest(self.ID, false);
                victim:GQ_PutQuestOnCooldown(self.ID, true);
                victim:SendGQTextNotification(true, "uiNotificationQuestFailed", self.Name, gQuest.Red, 10);
                victim:GQ_TrackQuest(self.ID, true);
            end

            if (IsValid(attacker) and attacker:IsPlayer()) then
                if (attacker:GQ_HasAcceptedQuest(self.ID)) then
                    attacker:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);