local QUEST = {};

QUEST.ID = 503
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[All] PVP Quest (Veteran)";
QUEST.Description = "Find and kill 50 people of the opposing faction without dying and receive a special crystal.";
QUEST.Objective = "Kill 50 people without dying.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Blackwing or Permaforst Crystal";
QUEST.ObjectiveRequirement = 50;
QUEST.ObjectiveClass = "player";
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 600;
QUEST.Enabled = false;

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    local howrare = math.random( 1, 1000 )
		if howrare >= 1 && howrare <= 500 then
			wOS:HandleItemPickup( ply, "[Mythic] Blackwing Crystal" )
			ply:AddSkillXP( 10000 )
		end
		if howrare >= 501 && howrare <= 1000 then
			wOS:HandleItemPickup( ply, "[Mythic] Permafrost Crystal" )
			ply:AddSkillXP( 10000 )
		end
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "gQuest.All_Zz_Pvp_Veteran", function(victim, inflictor, attacker)
        if (IsValid(victim)) then
            if (victim:GQ_HasAcceptedQuest(self.ID)) then
                victim:GQ_AbandonQuest(self.ID, false);
                victim:GQ_PutQuestOnCooldown(self.ID, true);
                victim:SendGQTextNotification(true, "uiNotificationQuestFailed", self.Name, gQuest.Red, 10);
                victim:GQ_TrackQuest(self.ID, true);
            end

            if (IsValid(attacker) and attacker:IsPlayer()) then
                if (attacker:GQ_HasAcceptedQuest(self.ID)) then
                    attacker:GQ_AddQuestProgress(self.ID, 1);
                end
            end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);