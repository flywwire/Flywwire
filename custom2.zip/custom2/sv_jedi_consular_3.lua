local QUEST = {};
 
QUEST.ID = 1103;
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[Jedi] Consular PVP Quest (3/5)";
QUEST.Description = "War is a never ending thing. I need you to kill people. The more you kill the closer you get to the reward. (Farming this quest will result in a complete wipe of your quest.)";
QUEST.Objective = "Kill 50 of any Sith Inquisitors.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Legendary Crystal, Credits. and XP";
QUEST.NeedsToHaveCompleted = 1102;
QUEST.ObjectiveRequirement = 50;
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 60;
QUEST.Enabled = true;
 
QUEST.JobWhitelist = {
	["Jedi Consular: Head Consular"] = true,
	["Jedi Consular: Diplomat"] = true,
	["Jedi Consular: Sage"] = true,
	["Jedi Consular: Healer"] = true,
	["Jedi Consular"] = true,
};
 
QUEST.TeamsThatShouldDie = {
    ["Sith Inquisitor: Grand Inquisitor"] = true,
	["Sith Inquisitor: Corruptor"] = true,
	["Sith Inquisitor: Assassin"] = true,
	["Sith Inquisitor: Sorcerer"] = true,
	["Sith Inquisitor"] = true,
}

local LegndaryCrystal = {
	"[Legendary] Blue Crystal (Saw Tooth)",
	"[Legendary] Light Blue Crystal (Saw Tooth)",
	"[Legendary] Green Crystal (Saw Tooth)",
	"[Legendary] Lime Green Crystal (Saw Tooth)",
	"[Legendary] Orange Crystal (Saw Tooth)",
	"[Legendary] Blood Orange Crystal (Saw Tooth)",
	"[Legendary] Pink Crystal (Saw Tooth)",
	"[Legendary] Purple Crystal (Saw Tooth)",
	"[Legendary] Red Crystal (Saw Tooth)",
	"[Legendary] Yellow Crystal (Saw Tooth)",
	"[Legendary] Blue Crystal (Cyan Core)",
	"[Legendary] Green Crystal (Green Core)",
	"[Legendary] Red Crystal (Orange Core)",
	"[Legendary] Magenta Crystal (Pink Core)",
	"[Legendary] Red Crystal (Yellow Core)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    local getitem = table.Random( LegndaryCrystal )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 4500 )
	ply:addMoney(50000) 
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "PVP_consular_3", function(victim, inflictor, attacker)
        if (IsValid(victim) and IsValid(attacker) and attacker:IsPlayer()) then
            if (attacker:GQ_HasAcceptedQuest(self.ID) and self.TeamsThatShouldDie[team.GetName(victim:Team())]) then
                attacker:GQ_AddQuestProgress(self.ID, 1);
            end
        end
    end);
 
    return true;
end
 
gQuest.RegisterQuest(QUEST);