local QUEST = {};
 
QUEST.ID = 1004;
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[Jedi] Sentinel PVP Quest (4/5)";
QUEST.Description = "War is a never ending thing. I need you to kill people. The more you kill the closer you get to the reward. (Farming this quest will result in a complete wipe of your quest.)";
QUEST.Objective = "Kill 75 of any Sith Intelligence";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 1003;
QUEST.ObjectiveRequirement = 75;
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 60;
QUEST.Enabled = true;

QUEST.JobWhitelist = {
	["Jedi Sentinel: Head Sentinel"] = true,
	["Jedi Sentinel: Shadow"] = true,
	["Jedi Sentinel: Investigator"] = true,
	["Jedi Sentinel: Watchman"] = true,
	["Jedi Sentinel"] = true,
};
 
QUEST.TeamsThatShouldDie = {
    ["Sith Intelligence: Minister of Intelligence"] = true,
	["Sith Intelligence: Keeper"] = true,
	["Sith Intelligence: Cipher"] = true,
	["Sith Intelligence: Agent"] = true,
	["Sith Intelligence"] = true,
}
 
function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:addMoney(12500); 
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "PVP_sentinel_4", function(victim, inflictor, attacker)
        if (IsValid(victim) and IsValid(attacker) and attacker:IsPlayer()) then
            if (attacker:GQ_HasAcceptedQuest(self.ID) and self.TeamsThatShouldDie[team.GetName(victim:Team())]) then
                attacker:GQ_AddQuestProgress(self.ID, 1);
            end
        end
    end);
 
    return true;
end
 
gQuest.RegisterQuest(QUEST);