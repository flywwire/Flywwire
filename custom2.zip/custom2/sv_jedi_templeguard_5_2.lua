local QUEST = {};
 
QUEST.ID = 1706;
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[Jedi] Temple Guard PVP Quest (5/5)";
QUEST.Description = "War is a never ending thing. I need you to kill people. The more you kill the closer you get to the reward. (Farming this quest will result in a complete wipe of your quest.)";
QUEST.Objective = "Kill 100 of any Imperial Guards.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 1705;
QUEST.ObjectiveRequirement = 100;
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 1800;
QUEST.Enabled = true;

QUEST.JobWhitelist = {
	["Jedi Temple Guard: Barsen'Thor"] = true,
	["Jedi Temple Guard: Paladin"] = true,
	["Jedi Temple Guard: Vanguard"] = true,
	["Jedi Temple Guard: Honor Guard"] = true,
	["Jedi Temple Guard"] = true,
};
 
QUEST.TeamsThatShouldDie = {
    ["Sith Imperial Guard: Emperor's Shield"] = true,
	["Sith Imperial Guard: Dark Honor Guard"] = true,
	["Sith Imperial Guard: Shadow Guard"] = true,
	["Sith Imperial Guard: Royal Guard"] = true,
	["Sith Imperial Guard"] = true,
}
 
function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 7500 )
	ply:addMoney(50000)
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "PVP_templeguards_5_2", function(victim, inflictor, attacker)
        if (IsValid(victim) and IsValid(attacker) and attacker:IsPlayer()) then
            if (attacker:GQ_HasAcceptedQuest(self.ID) and self.TeamsThatShouldDie[team.GetName(victim:Team())]) then
                attacker:GQ_AddQuestProgress(self.ID, 1);
            end
        end
    end);
 
    return true;
end
 
gQuest.RegisterQuest(QUEST);