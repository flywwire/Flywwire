local QUEST = {};
 
QUEST.ID = 1306;
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[Sith] Inquisitor PVP Quest (5/5)";
QUEST.Description = "War is a never ending thing. I need you to kill people. The more you kill the closer you get to the reward. (Farming this quest will result in a complete wipe of your quest.)";
QUEST.Objective = "Kill 100 of any Jedi Consulars.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Credits and XP";
QUEST.NeedsToHaveCompleted = 1305;
QUEST.ObjectiveRequirement = 100;
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 1800;
QUEST.Enabled = true;

QUEST.JobWhitelist = {
	["Sith Inquisitor: Grand Inquisitor"] = true,
	["Sith Inquisitor: Corruptor"] = true,
	["Sith Inquisitor: Assassin"] = true,
	["Sith Inquisitor: Sorcerer"] = true,
	["Sith Inquisitor"] = true,
};
 
QUEST.TeamsThatShouldDie = {
    ["Jedi Consular: Head Consular"] = true,
	["Jedi Consular: Diplomat"] = true,
	["Jedi Consular: Sage"] = true,
	["Jedi Consular: Healer"] = true,
	["Jedi Consular"] = true,
}
 
function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    ply:AddSkillXP( 7500 )
	ply:addMoney(50000) 
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "PVP_inquisitor_5_2", function(victim, inflictor, attacker)
        if (IsValid(victim) and IsValid(attacker) and attacker:IsPlayer()) then
            if (attacker:GQ_HasAcceptedQuest(self.ID) and self.TeamsThatShouldDie[team.GetName(victim:Team())]) then
                attacker:GQ_AddQuestProgress(self.ID, 1);
            end
        end
    end);
 
    return true;
end
 
gQuest.RegisterQuest(QUEST);