local QUEST = {};
 
QUEST.ID = 1405;
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[Sith] Intelligence PVP Quest (5/5)";
QUEST.Description = "War is a never ending thing. I need you to kill people. The more you kill the closer you get to the reward. (Farming this quest will result in a complete wipe of your quest.)";
QUEST.Objective = "Kill 100 of any Jedi Sentinels.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Mythic Crystal, Credits, and XP";
QUEST.NeedsToHaveCompleted = 1404;
QUEST.ObjectiveRequirement = 100;
QUEST.OneTimeQuest = true;
QUEST.Cooldown = 1;
QUEST.Enabled = true;

QUEST.JobWhitelist = {
	["Sith Intelligence: Minister of Intelligence"] = true,
	["Sith Intelligence: Keeper"] = true,
	["Sith Intelligence: Cipher"] = true,
	["Sith Intelligence: Agent"] = true,
	["Sith Intelligence"] = true,
};
 
QUEST.TeamsThatShouldDie = {
    ["Jedi Sentinel: Head Sentinel"] = true,
	["Jedi Sentinel: Shadow"] = true,
	["Jedi Sentinel: Investigator"] = true,
	["Jedi Sentinel: Watchman"] = true,
	["Jedi Sentinel"] = true,
}
 
local MythicalCrystal = {
	"[Mythic] Dark Green Crystal (Corrupted) (DI)",
	"[Mythic] Dark Blue Crystal (Corrupted) (DI)",
	"[Mythic] Dark Purple Crystal (Corrupted) (DI)",
	"[Mythic] Dark Red Crystal (Corrupted) (DI)",
	"[Mythic] Dark Blue Crystal (Saw Tooth) (DI)",
	"[Mythic] Dark Green Crystal (Saw Tooth) (DI)",
	"[Mythic] Dark Purple Crystal (Saw Tooth) (DI)",
	"[Mythic] Dark Red Crystal (Saw Tooth) (DI)",
	"[Mythic] Azure Crystal (Corrupted)",
	"[Mythic] Amber Crystal (Corrupted)",
	"[Mythic] Emerald Crystal (Corrupted)",
	"[Mythic] Fire Orange Crystal (Corrupted)",
	"[Mythic] Magenata Crystal (Corrupted)",
	"[Mythic] Violet Crystal (Corrupted)",
	"[Mythic] Amber Crystal (Saw Tooth) (DI)",
	"[Mythic] Azure Crystal (Saw Tooth) (DI)",
	"[Mythic] Emerald Crystal (Saw Tooth) (DI)",
	"[Mythic] Fire Orange Crystal (Saw Tooth) (DI)",
	"[Mythic] Magenata Crystal (Saw Tooth) (DI)",
	"[Mythic] Violet Crystal (Saw Tooth) (DI)",
	"[Mythic] Purple Crystal (Blue Core)",
	"[Mythic] Silver Crystal (Blue Core)",
	"[Mythic] Purple Crystal (Pink Core)",
	"[Mythic] Yellow Crystal (Pink Core)",
	"[Mythic] Blue Crystal (Yellow Core)",
	"[Mythic] Dark Blue Crystal (Blue Core)",
	"[Mythic] Dark Red Crystal (Red Core)",
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    local getitem = table.Random( MythicalCrystal )
		wOS:HandleItemPickup( ply, getitem )
		ply:AddSkillXP( 7500 )
	ply:addMoney(50000)
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "PVP_intelligence_5", function(victim, inflictor, attacker)
        if (IsValid(victim) and IsValid(attacker) and attacker:IsPlayer()) then
            if (attacker:GQ_HasAcceptedQuest(self.ID) and self.TeamsThatShouldDie[team.GetName(victim:Team())]) then
                attacker:GQ_AddQuestProgress(self.ID, 1);
            end
        end
    end);
 
    return true;
end
 
gQuest.RegisterQuest(QUEST);