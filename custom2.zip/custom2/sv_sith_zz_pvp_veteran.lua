local QUEST = {};

QUEST.ID = 1806;
QUEST.NPC = {1, 2, 3};
QUEST.Name = "[Sith] PVP Quest (Veteran)";
QUEST.Description = "Find and kill 50 jedi without dying and receive a special crystal. (Farming this quest will result in a complete wipe of your quest.)";
QUEST.Objective = "Kill 50 jedi without dying.";
QUEST.HUDObjective = "";
QUEST.OnCompleteDescription = "Congratulations on completing the quest, take your reward.";
QUEST.Rewards = "Blackwing or Permaforst Crystal";
QUEST.ObjectiveRequirement = 50;
QUEST.OneTimeQuest = false;
QUEST.Cooldown = 600;
QUEST.Enabled = true;

QUEST.JobWhitelist = {
	["Sith Empire: Emperor"] = true,
	["Sith Empire: Emperor's Wrath"] = true,
	["Sith Imperial Guard: Emperor's Shield"] = true,
	["Sith Imperial Guard: Dark Honor Guard"] = true,
	["Sith Imperial Guard: Shadow Guard"] = true,
	["Sith Imperial Guard: Royal Guard"] = true,
	["Sith Imperial Guard"] = true,
	["Sith Warrior: Warlord"] = true,
	["Sith Warrior: Conqueror"] = true,
	["Sith Warrior: Juggernaut"] = true,
	["Sith Warrior: Marauder"] = true,
	["Sith Warrior"] = true,
	["Sith Intelligence: Minister of Intelligence"] = true,
	["Sith Intelligence: Keeper"] = true,
	["Sith Intelligence: Cipher"] = true,
	["Sith Intelligence: Agent"] = true,
	["Sith Intelligence"] = true,
	["Sith Inquisitor: Grand Inquisitor"] = true,
	["Sith Inquisitor: Corruptor"] = true,
	["Sith Inquisitor: Assassin"] = true,
	["Sith Inquisitor: Sorcerer"] = true,
	["Sith Inquisitor"] = true,
	["Sith Empire: Darth"] = true,
	["Sith Empire: Sith Lord"] = true,
	["Sith Empire: Apprentice"] = true,
	["Sith Empire: Acolyte"] = true,
	["Sith Empire: Darth Sidious"] = true,
	["Sith Empire: Darth Vader"] = true,
	["Sith Empire: Darth Maul"] = true,
	["Sith Empire: Darth Tyranus"] = true,
	["Sith Empire: Savage Opress"] = true,
	["Sith Empire: Starkiller"] = true,
	["Sith Empire: Darth Bane"] = true,
	["Sith Empire: Darth Malgus"] = true,
	["Sith Empire: Darth Revan"] = true,
	["Sith Empire: Darth Malak"] = true,
	["Sith Empire: Darth Marr"] = true,
	["Sith Empire: Darth Jadus"] = true,
	["Sith Empire: Darth Nihilus"] = true,
	["Sith Empire: Darth Sion"] = true,
	["Sith Empire: Kylo Ren"] = true,
};

QUEST.TeamsThatShouldDie = {
    ["Jedi Order: Grandmaster"] = true,
	["Jedi Order: Master Of The Order"] = true,
	["Jedi Temple Guard: Barsen'Thor"] = true,
	["Jedi Temple Guard: Paladin"] = true,
	["Jedi Temple Guard: Vanguard"] = true,
	["Jedi Temple Guard: Honor Guard"] = true,
	["Jedi Temple Guard"] = true,
	["Jedi Guardian: Battlemaster"] = true,
	["Jedi Guardian: Weapon Specialist"] = true,
	["Jedi Guardian: Instructor"] = true,
	["Jedi Guardian: Peacekeeper"] = true,
	["Jedi Guardian"] = true,
	["Jedi Sentinel: Head Sentinel"] = true,
	["Jedi Sentinel: Shadow"] = true,
	["Jedi Sentinel: Investigator"] = true,
	["Jedi Sentinel: Watchman"] = true,
	["Jedi Sentinel"] = true,
	["Jedi Consular: Head Consular"] = true,
	["Jedi Consular: Diplomat"] = true,
	["Jedi Consular: Sage"] = true,
	["Jedi Consular: Healer"] = true,
	["Jedi Consular"] = true,
	["Jedi Order: Master"] = true,
	["Jedi Order: Knight"] = true,
	["Jedi Order: Padawan"] = true,
    ["Jedi Order: Youngling"] = true,
	["Jedi Order: Luke Skywalker"] = true,
	["Jedi Order: Anakin Skywalker"] = true,
	["Jedi Order: Obi-Wan Kenobi"] = true,
	["Jedi Order: Mace Windu"] = true,
	["Jedi Order: Shaak Ti"] = true,
	["Jedi Order: Kit Fisto"] = true,
	["Jedi Order: Ahsoka Tano"] = true,
	["Jedi Order: Satele Shan"] = true,
	["Jedi Order: Bastila Shan"] = true,
	["Jedi Order: Light Revan"] = true,
	["Jedi Order: Count Dooku"] = true,
	["Jedi Order: Galen Marek"] = true,
	["Jedi Order: Mara Jade"] = true,
	["Jedi Order: Kyle Katarn"] = true,
	["Jedi Order: Rey"] = true,
}

function QUEST:OnAccept(ply)
    return true;
end

function QUEST:OnCompleted(ply)
    return true;
end

function QUEST:OnObjectiveUpdated(ply)
    return true;
end

function QUEST:OnDelivered()
    return true;
end

function QUEST:OnObjectiveSpawned(obj)
    return true;
end

function QUEST:OnQuestDisbanded(ply)
    return true;
end

function QUEST:RewardFunction(ply)
    local howrare = math.random( 1, 1000 )
		if howrare >= 1 && howrare <= 500 then
			wOS:HandleItemPickup( ply, "[Mythic] Blackwing Crystal" )
			ply:AddSkillXP( 10000 )
		end
		if howrare >= 501 && howrare <= 1000 then
			wOS:HandleItemPickup( ply, "[Mythic] Permafrost Crystal" )
			ply:AddSkillXP( 10000 )
		end
end

function QUEST:OnQuestInitialized()
    hook.Add("PlayerDeath", "gQuest.Sith_Zz_Pvp_Veteran", function(victim, inflictor, attacker)
        if (IsValid(victim)) then
            if (victim:GQ_HasAcceptedQuest(self.ID)) then
                victim:GQ_AbandonQuest(self.ID, false);
                victim:GQ_PutQuestOnCooldown(self.ID, true);
                victim:SendGQTextNotification(true, "uiNotificationQuestFailed", self.Name, gQuest.Red, 10);
                victim:GQ_TrackQuest(self.ID, true);
            end

            if (IsValid(victim) and IsValid(attacker) and attacker:IsPlayer()) then
				if (attacker:GQ_HasAcceptedQuest(self.ID) and self.TeamsThatShouldDie[team.GetName(victim:Team())]) then
					attacker:GQ_AddQuestProgress(self.ID, 1);
				end
			end
        end
    end);

    return true;
end

gQuest.RegisterQuest(QUEST);